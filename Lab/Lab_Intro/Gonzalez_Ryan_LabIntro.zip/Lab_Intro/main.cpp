/* 
 * File:   main.cpp
 * Author: Professor
 *
 * Created on June 19, 2019, 10:33 PM
 */


#include <iostream>
using namespace std;

int main() {
    cout << "Hello World" << endl;
    return 0;
}

